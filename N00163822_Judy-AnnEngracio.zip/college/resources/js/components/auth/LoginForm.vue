<template>
  <div class="col-md-6">
      <div class="card">
          <div class="card-header">Login</div>

          <div class="card-body">
              <form v-on:submit="login()">
                  <div class="form-group">
                      <label>Email</label>
                      <input type="text" v-model="user.email" class="form-control">
                  </div>
                  <div class="form-group">
                      <label>Password</label>
                      <input type="text" v-model="user.password" class="form-control">
                  </div>
                  <div class="form-group">
                      <button class="btn btn-primary">Login</button>
                      <p class="text-danger" v-if="errorMessage != ''">{{ errorMessage }}</p>
                  </div>
              </form>
          </div>
      </div>
  </div>
</template>

<script>
    export default {
        data: function () {
            return {
                user: {
                    email: '',
                    password: ''
                },
                errorMessage: ''
            }
        },
        mounted() {
            var app = this;
            //The user homepage is rendered if there is a token
            if (localStorage.getItem('token') !== null) {
                app.$router.replace({name: 'home'});
            }
        },
        methods: {
            login() {
                event.preventDefault();
                var app = this;
                axios.post('/api/login', app.user)
                    .then(function (resp) {
                        localStorage.setItem('token', resp.data.token);
                        app.$router.push({name: 'home'});
                    })
                    .catch(function (resp) {
                        app.errorMessage = "It didn't work!";
                    });
            }
        }
    }
</script>
