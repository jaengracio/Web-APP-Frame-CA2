<template>
    <div class="card">
        <div class="card-header">Enrolments list</div>

        <div class="card-body">
            <div class="form-group">
                <router-link :to="{ name: 'enrolments.create' }" class="btn btn-success">
                    Create new Enrolment
                </router-link>
            </div>
            <!-- If the enrolments variable is empty, this displays the message to the user.
                 If it is not empty, a table with all the enrolments data is shown. -->
            <p v-if="enrolments.length == 0">There are no enrolments</p>
            <table v-if="enrolments.length != 0" class="table table-hover table-responsive-md">
                <thead class="thead-dark">
                    <tr>
                        <th>Status</th>
                        <th>Course</th>
                        <th>Student</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="enrolment in enrolments">
                        <td>{{ enrolment.status }}</td>
                        <td>{{ enrolment.course.title }}</td>
                        <td>{{ enrolment.student.name }}</td>
                        <td>{{ enrolment.date }}</td>
                        <td>{{ enrolment.time }}</td>
                        <td>
                            <!-- This link is button that directs the user to the edit page of an enrolment.
                                 The link passes an id as a parameter, so that the enrolment with that id is
                                 found in the array of enrolments, and displayed to the user. -->
                            <router-link :to="{ name: 'enrolments.edit', params: { id: enrolment.id } }" class="btn btn-warning">Edit</router-link>
                        </td>
                        <td>
                            <!-- This button is an event listener for deleting an enrolment.
                            It passes the id of an enrolment as a parameter so that only a single
                            enrolment is deleted at a time. -->
                            <button class="btn btn-danger" v-on:click="deleteEnrolment(enrolment.id)">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            var app = this;
            var token = localStorage.getItem('token');
            axios.get('/api/enrolments', {
                headers: { Authorization: "Bearer " + token }
            })
            // These two functions wait for a response from the get request the use sent.
            // If the response is a success, the data is set to the variable. If not,
            // an error message will pop up.

            .then(function (resp) {
                console.log(resp.data);
                app.enrolments = resp.data;
            })
            .catch(function (resp) {
                console.log(resp);
                alert('Could not load enrolments');
            });
        },
        data() {
            return {
              // This returns an array of enrolment objects.
                enrolments: []
            }
        },
        methods: {
            deleteEnrolment(enrolmentId) {
                var app = this;
                if (confirm("Are you sure you want to delete this enrolment (id =" + enrolmentId + " )?")) {
                    var token = localStorage.getItem('token');
                    axios.delete('/api/enrolments/' +  enrolmentId, {
                        headers: { Authorization: "Bearer " + token }
                    })
                    /* This looks for an id of an enrolment object and stores it in a variable,
                     so that it can be removed from the enrolments array. */
                    .then(function (resp) {
                        var index = app.enrolments.findIndex(function (enrolment) {
                            return enrolment.id == enrolmentId;
                        });
                        /* This removes the enrolment object from the array starting
                           from the value of the index variable and deleting one. */
                        app.enrolments.splice(index, 1);
                    })
                    /* This shows an error message in a pop box if the response is unsuccessful. */
                    .catch(function (resp) {
                        alert("Could not delete enrolment!!");
                    });
                }
            }
        }
    }
</script>
