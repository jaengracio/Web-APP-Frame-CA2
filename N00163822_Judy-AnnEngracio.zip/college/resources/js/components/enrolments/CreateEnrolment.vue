<template>
    <div class="card">
        <div class="card-header">Create new enrolment</div>

        <div class="card-body">
            <form v-on:submit="saveForm()">
                <div class="form-row">
                    <div class="col-md-6 form-group">
                        <label>Student</label>
                        <select v-model="enrolment.student_id" class="form-control">
                            <!-- This for loop shows a list of all the student names in a
                                 dropdown box instead of their ids. This makes it easier for
                                 the user to choose a student when creating a new enrolment. -->
                            <option v-for="student in students" :value="student.id">
                                {{ student.name }}
                            </option>
                        </select>
                        <p class="text-danger" v-if="errors.student_id">{{ errors.student_id[0] }}</p>
                    </div>
                    <div class="col-md-6 form-group">
                        <label>Course</label>
                        <select v-model="enrolment.course_id" class="form-control">
                            <option v-for="course in courses" :value="course.id">
                                {{ course.title }}
                            </option>
                        </select>
                        <p class="text-danger" v-if="errors.course_id">{{ errors.course_id[0] }}</p>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-md-6 form-group">
                        <label>Date</label>
                        <input type="date" v-model="enrolment.date" class="form-control">
                        <p class="text-danger" v-if="errors.date">{{ errors.date[0] }}</p>
                    </div>
                    <div class="col-md-6 form-group">
                        <label>Time</label>
                        <input type="time" v-model="enrolment.time" class="form-control">
                        <p class="text-danger" v-if="errors.time">{{ errors.time[0] }}</p>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" v-model="enrolment.status" name="registered" id="registered" value="registered">
                        <label class="form-check-label" for="registered">Registered</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" v-model="enrolment.status" name="attending" id="attending" value="attending">
                        <label class="form-check-label" for="attending">Attending</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" v-model="enrolment.status" name="deferred" id="deferred" value="deferred">
                        <label class="form-check-label" for="deferred">Deferred</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" v-model="enrolment.status" name="withdrawn" id="withdrawn" value="withdrawn">
                        <label class="form-check-label" for="withdrawn">Withdawn</label>
                    </div>
                    <p class="text-danger" v-if="errors.status">{{ errors.status[0] }}</p>
                </div>
                <br>
                <div class="form-row">
                    <div class="col-md-12 form-group">
                        <button class="btn btn-primary">Create</button>
                        <router-link to="/home/enrolments" class="btn btn-secondary">Cancel</router-link>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
    export default {
        // The data acts as a get and set method. For this component, it retrieves data.
        data: function () {
            return {
                enrolment: {
                    date: '',
                    time: '',
                    status: '',
                    student_id: '',
                    course_id: '',
                },
                students: [],
                courses: [],
                errors: {}
            }
        },
        mounted() {
            var app = this;
            var token = localStorage.getItem('token');
            axios.get('/api/students', {
                headers: { Authorization: "Bearer " + token }
            })
            .then(function (resp) {
                console.log(resp.data);
                app.students = resp.data;
            })
            .catch(function (resp) {
                console.log(resp);
                alert('Could not load students');
            });

            axios.get('/api/courses', {
                headers: { Authorization: "Bearer " + token }
            })
            .then(function (resp) {
                console.log(resp.data);
                app.courses = resp.data;
            })
            .catch(function (resp) {
                console.log(resp);
                alert('Could not load courses');
            });
        },
        methods: {
            saveForm() {
                event.preventDefault();
                var app = this;
                var newEnrolment = app.enrolment;
                var token = localStorage.getItem('token');
                var xhr = axios.post('/api/enrolments', newEnrolment, {
                    headers: { Authorization: "Bearer " + token }
                    });

                xhr = xhr.then(function (resp) {
                        app.$router.push({name: 'enrolments'});
                    });

                xhr = xhr.catch(function (resp) {
                        app.errors = resp.response.data;
                    });
            }
        }
    }
</script>
