/* The dependecies and components needed are imported so that they can be used
   and customised. */

require('./bootstrap');

import Vue from 'vue';
import VueRouter from 'vue-router';
import LoginForm from './components/auth/LoginForm.vue';
import UserHome from './components/home/UserHome.vue';
import EnrolmentsIndex from './components/enrolments/EnrolmentsIndex.vue';
import CreateEnrolment from './components/enrolments/CreateEnrolment.vue';
import EditEnrolment from './components/enrolments/EditEnrolment.vue';

Vue.use(VueRouter);

/* Each route is mapped to a component. */
const routes = [
  {
      path: '/',
      name: 'login',
      components: {
        loginForm: LoginForm
      }
  },
  {
    path: '/home',
    component: UserHome,
    name: 'home',
    children: [
        {
            path: 'enrolments',
            name: 'enrolments',
            component: EnrolmentsIndex
        },
        {
            path: 'enrolments/create',
            name: 'enrolments.create',
            component: CreateEnrolment
        },
        {
            path: 'enrolments/:id/edit',
            name: 'enrolments.edit',
            component: EditEnrolment
        }
    ]
  },
];

/* A new instance of the VueRouter is created and the values of the
   routes constant are passed to the routes property. */
const router = new VueRouter({
    routes: routes
});

const app = new Vue({
    el: '#app',
    router: router
});
