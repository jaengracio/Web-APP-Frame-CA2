<?php /* C:\Users\judya\Downloads\college\resources\views/welcome.blade.php */ ?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
            <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- Script -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div id="app">
            <main class="py-4">
                <div class="container">
                    <div class="col-md-12">
                        <!-- This shows the login form on the welome page. -->
                        <router-view name="loginForm"></router-view>
                        <!-- When the user has successfully logged in, this displays
                        the user home page. -->
                        <router-view></router-view>
                    </div>
                </div>
            </main>
        </div>
    </body>
</html>
