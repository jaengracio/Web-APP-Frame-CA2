<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/login', 'API\PassportController@login');
Route::post('/register', 'API\PassportController@register');

Route::middleware('auth:api')->group(function () {
    Route::get('/user', 'API\PassportController@user');
    Route::get('/logout', 'API\PassportController@logout');

    Route::get('/enrolments', 'API\EnrolmentController@index')->name('api.enrolments.index');
    Route::get('/enrolments/{id}', 'API\EnrolmentController@show')->name('api.enrolments.show');
    Route::post('/enrolments', 'API\EnrolmentController@store')->name('api.enrolments.store');
    Route::put('/enrolments/{id}', 'API\EnrolmentController@update')->name('api.enrolments.update');
    Route::delete('/enrolments/{id}', 'API\EnrolmentController@destroy')->name('api.enrolments.delete');

    Route::get('/students', 'API\StudentController@index')->name('api.students.index');
    Route::get('/courses', 'API\CourseController@index')->name('api.courses.index');
});
